import json
import math
import re
import matplotlib.pyplot as plt

word_counts = {}
with open('cranfield\cranfield_data.json', 'r') as file:
    doc_data = json.load(file)

with open('cranfield\cran.qry.json', 'r') as file:
    query_data = json.load(file)

with open('cranfield\cranqrel.json', 'r') as file:
    doc_query_rel = json.load(file)
 

def get_word_counts():
    mu =0
    with open('cranfield\cranfield_data.json', 'r') as file:
        data = json.load(file)
    for i in data:
        body = re.sub(r'[^\w\s]', '',str(i['body'] ))
        for j in body.split(' '):
            
            if j == '' or j==' ' or j=='.':
                continue
            else:
                mu = mu +1
                if j in word_counts.keys():
                    word_counts[j] = word_counts[j] +1
                else:
                    word_counts[j] =1
    return mu


total_length = get_word_counts()

def com_word_list(w1,w2):
    lst = []
    w1 = re.sub(r'[^\w\s]', '',str(w1) )
    w2 = re.sub(r'[^\w\s]', '',str(w2) )
    lst1 = w1.split(' ')
    lst2 = w2.split(' ')

    for x in lst1:
        if x != '' and x!= ' ' and x!='.' and x in lst2:
            lst.append(x)

    return lst

def get_wd(text):
    lst = {}
    len=0
    w1 = re.sub(r'[^\w\s]', '',str(text) )
    lst1 = w1.split(' ')
    for x in lst1:
        if x == '' or x ==' ' or x =='.':
            continue
        else:
            len = len +1
            if x in lst.keys():
                lst[x] = lst[x] +1
            else:
                lst[x] =1

    return lst,len

def JM_Score(query,doc,l):
    query_dict,q_l = get_wd(query)
    doc_dict,d_l = get_wd(doc)
    com_list = com_word_list(query,doc)
    score = 0
    for x in com_list:
        score = score + (query_dict[x]*(math.log(1 + (((1-l)*doc_dict[x])/(l*(word_counts[x]/total_length)*d_l)))))
    return score

def Dp_Score(query,doc,u):
    query_dict,q_l = get_wd(query)
    doc_dict,d_l = get_wd(doc)
    com_list = com_word_list(query,doc)
    score = 0
    for x in com_list:
        score = score + (query_dict[x]*(math.log(1 + ((doc_dict[x])/(u*(word_counts[x]/total_length))))))

    return score - (q_l*math.log(d_l + u))

def search_rel(q_n,d_n):
    for ele in doc_query_rel:
        if int(ele["query_num"]) == int(q_n) and int(ele["id"]) == d_n:
            return ele["position"]

    return 5

def q_d_JMscores(l):
    out = []
    for q in query_data:
        lst = []
        if type(q["query"]) is not str:
            continue

        for d in doc_data:
            lst.append(JM_Score(q["query"],d["body"],l))
 
        res = sorted(range(len(lst)), key = lambda sub: lst[sub])[-5:]
        sum =0
        
        for x in res:    
            sum = sum +search_rel(q["query number"], x+1)

        out.append(sum/5)
        print("doing")
        

    return out

def q_d_DPscores(u):
    out = []
    for q in query_data:
        lst = []
        if type(q["query"]) is not str:
            continue

        for d in doc_data:
            lst.append(Dp_Score(q["query"],d["body"],u))

        
        res = sorted(range(len(lst)), key = lambda sub: lst[sub])[-5:]
        sum =0
        
        for x in res:   
            
            sum = sum +search_rel(q["query number"], x+1)

        out.append(sum/5)
        print("doing")
        

    return out

def draw_graph(lst,name,i):
    plt.figure(i)
    plt.hist(lst)
    plt.title(name)
    plt.xlabel("bins")
    plt.ylabel("count")
    plt.savefig(name)


def draw_plot(lst1,lst2,name,i,x_label):
    plt.figure(i)
    plt.plot(lst1,lst2)
    plt.title(name)
    plt.xlabel(x_label)
    plt.ylabel("dataset_level_performance")
    plt.savefig(name)


def get_graph_lambdas():
    lst = [0.05,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
    avg = []
    for i in range(len(lst)):
        test = q_d_JMscores(lst[i])
        draw_graph(test,"hist_JM_"+str(i),i)
        avg.append(sum(test)/len(test))

    draw_plot(lst,avg,"lamba_vs_performance_plot",i+1,"lambda")

def get_graph_mu():
    lst = [100,500,1000,2000,4000,8000,10000]
    avg = []
    for i in range(len(lst)):
        test = q_d_DPscores(lst[i])
        draw_graph(test,"hist_DP_"+str(i),i)
        avg.append(sum(test)/len(test))

    draw_plot(lst,avg,"mu_vs_performance_plot",i+1,"mu")

#get_graph_lambdas()
get_graph_mu()
